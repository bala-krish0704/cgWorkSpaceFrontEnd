import { useCallback, useState } from "react";
import './Register.css';
import {useFormik} from 'formik';
import * as yup from "yup";

const Register = (props) =>{
    //define state for accepting register form values
    /* const[regForm,setRegForm] = useState({
        fullName : "",
        userName : "",
        password : "",
        confirmPassword : "",
        email : ""
    }); */

    const registerFormSchema = yup.object().shape({
            fullName : yup.string().min(3).required(),
            userName : yup.string().min(6).required(),
            password : yup.string().min(8).required(),
            confirmPassword : yup.string().min(8).required(),
            email : yup.string().email.required()
    });

    const handleOnSubmit = (values) => {
        const fullData = Object.keys(values)
                                .map((key) => values[key])
                                .join(" ");
        alert(`User Data = ${fullData}`);
    };

    const formik = useFormik({
        initialValues:{
            fullName : "",
            userName : "",
            password : "",
            confirmPassword : "",
            email : ""
        },
        validationSchema :registerFormSchema,
        onSubmit: handleOnSubmit,
    });

    const onUpdateField = useCallback(
      (key,value) => 
        formik.setValues({
            ...formik.values,
            [key]: value,
        }),
        [formik]
        ) ;

    return(
        <form  onSubmit={formik.handleSubmit}>
            <div className="formGroup table-reponse">
              <label  for="">Full Name</label>
              <input type="text" name="fullName" 
                className="formField" 
                value = {formik.values.fullName}
                placeholder="Enter Full Name"
                onChange={(e) =>onUpdateField("fullName",e.target.value)}/>
                <small style={{color:"red"}}>{formik.errors.fullName}</small>
            </div>
            <div className="formGroup">
              <label className="formLabel" for="">User Name</label>
              <input type="text" name="userName" className="formField" 
                value = {formik.values.userName}
                placeholder="Enter User Name"
                onChange={(e) =>onUpdateField("userName",e.target.value)}/>
                 <small style={{color:"red"}}>{formik.errors.userName}</small>
            </div>
            <div className="formGroup">
              <label className="formLabel" for="">password</label>
              <input type="password" name="password" className="formField" 
                value = {formik.values.password}
                placeholder="Enter Password"
                onChange={(e) =>onUpdateField("password",e.target.value)}/>
                 <small style={{color:"red"}}>{formik.errors.password}</small>
            </div>
            <div className="formGroup">
              <label className="formLabel" for="">confirmPassword</label>
              <input type="password" name="confirmPassword" className="formField" 
                value = {formik.values.confirmPassword}
                placeholder="Enter Confirm Password"
                onChange={(e) =>onUpdateField("confirmPassword",e.target.value)}/>
                 <small style={{color:"red"}}>{formik.errors.confirmPassword}</small>
            </div>
            <div className="formGroup">
              <label className="formLabel" for="">email</label>
              <input type="text" name="email" className="formField" 
                value = {formik.values.email}
                placeholder="Enter email"
                onChange={(e) =>onUpdateField("email",e.target.value)}/>
                 <small style={{color:"red"}}>{formik.errors.email}</small>
            </div>
            <div className="formActions">
                <button type="submit" className="formSubmitBtn"
                disabled={!formik.isValid}>
                    Register
                </button>
            </div>
        </form>
    );
};

export default Register;