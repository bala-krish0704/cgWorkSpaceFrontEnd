
import React,{Component} from "react";
import Child from "./Child.js";
import {Sample} from "./Sample.js";
import Employee from "./Employee.js";

export default class Parent extends Component{
    state = {
        msg : "Hello Good Morning"
    }
    handleButtonClick =() => {
        console.log("button clicked");
        //this.state.msg ="Welcome";
        this.setState({
            msg:"Welcome"
        });
    }
    render(){
        //javscript object
        let emp = {
            empid : 4322,
            empname : "Rama",
            empsalary : 45350
        }
        return(
            <div>
                <h1>Parent Component</h1>
                <Child title="Iam text from parent component"></Child>
                <Sample data="hello from props of functional component"></Sample>
                <Employee emp = {emp} />
                {/* print  state value */}
                <h1>{this.state.msg}</h1>
                {/*change value of the state*/}
                <button type="button" onClick={this.handleButtonClick}>click</button>
            </div>
        )
    }
}