import React,{Component} from "react";

export default class Employee extends Component{
    render(){
        return(
            <div>
                <h1>{this.props.title}</h1>
                <label>Employee Id :
                    <h4 style={{display:"inline"}}>{this.props.emp.empid}</h4>
                </label><br/>
                <label>Employee Name : 
                    <h4 style={{display:"inline"}}>{this.props.emp.empname}</h4>
                </label>
            </div>
        )
    }
}