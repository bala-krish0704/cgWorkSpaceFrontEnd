import React from "react";
export class Student extends React.Component
{
    render(){
        return(
            <div>
                <h1>Student Details</h1>
                <h3>{this.props.stud.studid}</h3>
                <h3>{this.props.stud.studname}</h3>
            </div>
        )
    }
}