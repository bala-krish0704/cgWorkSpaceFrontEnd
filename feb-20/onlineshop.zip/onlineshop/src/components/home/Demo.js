import {Student} from "./Student";
 var student = {
    studid : 45564,
    studname :"Jeyaprakash"
}
export const Demo = (props) => (
    
    <div>
       <h1>Hello from Functional Components</h1>
        <Student stud={student}/>
    </div>
    
)