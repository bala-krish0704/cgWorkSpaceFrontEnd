
import React,{Component} from "react";

export default class Child extends Component{
    render(){
        return(
            <div>
                <h1>Child Component</h1>
                <h3>{this.props.title}</h3>
            </div>
        )
    }
}