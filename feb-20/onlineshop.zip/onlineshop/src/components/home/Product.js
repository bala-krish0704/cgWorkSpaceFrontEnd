import { useState } from "react";

let empl = {
    empid : 112636,
    empname : "KrishnaRam",
    empsal : 95800
}
export const Product = () => {
    //const[empl,setEmpl]=useState(empl);
    /*
    const[empl,setEmpl]=useState({
        empid : 112636,
        empname : "KrishnaRam",
        empsal : 95800
    }); */
    const myStyle = {
        color:"Green",
        padding:20
    }
    const[empId,setEmpId]=useState(empl.empid);
    const[empName,setEmpName]=useState(empl.empname);
    const[empSal,setEmpSal]=useState(empl.empsal);
    return(
        <div>
            <h3 style={myStyle}>{empId}</h3>
            <h3 style={myStyle}>{empName}</h3>
            <h3 style={myStyle}>{empSal}</h3>
        </div>
    )
}