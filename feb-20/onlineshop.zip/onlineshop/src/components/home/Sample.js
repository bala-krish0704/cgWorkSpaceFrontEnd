import { useState } from "react";
import Employee from "./Employee.js";
export const Sample = (props) =>{
    let empl = {
        empid : 423365462,
        empname : "Krishna",
        empsal : 454009
    }
    //state in functional component
    const[msgValue,setMsgValue] = useState("Hello from useState");
    return (
        <div>
            <h1>Functional Component</h1>
            <h3>{props.data}</h3>
            <Employee emp ={empl} title="Employee details from sample.js"/>
            <h1>Value of the state using functional components</h1>
            <h3 style={{color:"GrayText"}}>{msgValue}</h3>
            <h3>click here to change the value of state</h3>
            {/*change value of the state*/}
            <button type="button" onClick={() =>setMsgValue(("changed value of the state"))}>
                Click
            </button>
        </div>
    )
}