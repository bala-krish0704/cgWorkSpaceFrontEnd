
import './App.css';
import Register from './components/Register/Register';
function App() {
  return (
    <div >
      <h1>Online Shopping</h1>
      <Register />
    </div>
  );
}

export default App;
