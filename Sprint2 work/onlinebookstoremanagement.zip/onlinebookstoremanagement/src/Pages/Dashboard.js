import { Navbar } from "../components/Home/Navbar";


export function Dashboard(){
    return(
        <div>
            <Navbar />
        </div>
    );
}